
package hilos_ejemplo;

import javax.swing.JLabel;

/**
 *
 * @author Personal
 */
public class Hilo1 implements  Runnable{
    private int segundo;
    private int minuto;
    public boolean b;
    JLabel lbl;
    
    public Hilo1 (JLabel lbl){
    this.lbl=lbl;
     reset();
    }
    public void reset(){
    segundo=0;
    minuto=0;
    b= false;
    lbl.setText("0");
    }
    public void run(){
        try {
            while (true) {
              if (b){
              accion();
              }    
              Thread.sleep(1);
            }
        } catch (Exception e) {
            System.out.println("ERROR");
        }
    }

    public void accion(){
    segundo ++;
    
    
if(segundo==60) { segundo=0; minuto++; }
if(minuto==60)
 { minuto=0; }

lbl.setText(minuto+":"+segundo);
  
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            System.out.println("Hilo interrumpido");
        }
  
    }   

    public int getSegundo() {
        return segundo;
    }

    public void setSegundo(int segundo) {
        this.segundo = segundo;
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }

    public boolean isB() {
        return b;
    }

    public void setB(boolean b) {
        this.b = b;
    }

    public JLabel getLbl() {
        return lbl;
    }

    public void setLbl(JLabel lbl) {
        this.lbl = lbl;
    }
}
